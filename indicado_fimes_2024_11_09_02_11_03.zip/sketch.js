let campoIdade;
let campoAnime;
let campoTerror;

function setup() {
  createCanvas(800, 400);
  createElement("h2", "Recomendador de filmes");
  createSpan("Sua idade:");
  campoIdade = createInput("5");
  campoAnime = createCheckbox("Gosta de Anime?");
  campoTerror = createCheckbox("Gosta de Terror?");
}

function draw() {
  background("white");
  let idade = campoIdade.value();
  let gostaDeAnime = campoAnime.checked();
  let gostaDeTerror = campoTerror.checked();
  let recomendacao = geraRecomendacao(idade, gostaDeAnime, gostaDeTerror);

  fill(color(16, 20, 115));
  textAlign(CENTER, CENTER);
  textSize(38);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade, gostaDeAnime, gostaDeTerror) {
  if (idade >= 12) {
    if (idade >= 18) {
      return "Baki Hanma";
    } else {
      if (idade >= 14) {
        if(gostaDeAnime || gostaDeTerror) {
          return "Uzumaki";          
        } else{
         return "Planeta dos Macacos: O Reinado";
        }
      } else {
        if (gostaDeAnime) {
          return "Spy X Family";
        } else {
          return "Batman: O Cavaleiro das Trevas";
        }
      }
    }
  } else {
    if (gostaDeAnime) {
      return "Pokémon, O Filme 1: Mewtwo vs Mew";
    } else {
      return "Menino Maluquinho: O Filme";
    }
  }
}
